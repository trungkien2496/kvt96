//
//  ViewController.swift
//  RacingZ
//
//  Created by Trung Kien on 7/14/17.
//  Copyright © 2017 Trung Kien. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var xeBoMay: UIImageView!
    
    @IBOutlet weak var xe1: UIImageView!
    
    @IBOutlet weak var xe2: UIImageView!
    
    @IBOutlet weak var xe3: UIImageView!
    
    var timer:Timer!
    
    @IBAction func btnPlay(_ sender: Any) {
        //
        xe2.frame.origin.y = 0 - 200
        xe1.frame.origin.y = 0 - 300
        xe3.frame.origin.y = 0 - 400
        lblDiem.text = "0"
        timer = Timer.scheduledTimer(timeInterval: 0.005, target: self, selector: Selector("ChayXe"), userInfo: nil, repeats: true)
    }
    func ChayXe(){
        xe1.frame = CGRect(x: xe1.frame.origin.x, y: xe1.frame.origin.y + 1, width: xe1.frame.size.width, height: xe1.frame.size.height)
        if xe1.frame.origin.y == h {
                xe1.frame.origin.y = 0 - 135
            var r:Float = Float(arc4random_uniform(UInt32(w)))
            xe1.frame = CGRect(x:CGFloat(r ), y: xe1.frame.origin.y, width: xe1.frame.size.width, height: xe1.frame.size.height) //chỗ này thay = CGFloat(r) cũng đc
            
            var diem:Int? = Int(lblDiem.text!)
            diem = diem! + 1
            lblDiem.text = String(diem!)
            
        }
        //xe2
        xe2.frame = CGRect(x: xe2.frame.origin.x, y: xe2.frame.origin.y + 1, width: xe2.frame.size.width, height: xe2.frame.size.height)
        if xe2.frame.origin.y == h {
            xe2.frame.origin.y = 0 - 190
            var r:Float = Float(arc4random_uniform(UInt32(w)))
            xe2.frame = CGRect(x:CGFloat(r ), y: xe2.frame.origin.y, width: xe2.frame.size.width, height: xe2.frame.size.height) //chỗ này thay = CGFloat(r) cũng đc
            
            //var diem:Int? = lblDiem.text?.ToInt()
            var diem:Int? = Int(lblDiem.text!)
            diem = diem! + 1
            lblDiem.text = String(diem!)
        }
        //xe3
        xe3.frame = CGRect(x: xe3.frame.origin.x, y: xe3.frame.origin.y + 1, width: xe3.frame.size.width, height: xe3.frame.size.height)
        if xe3.frame.origin.y == h {
            xe3.frame.origin.y = 0 - 150
            var r:Float = Float(arc4random_uniform(UInt32(w)))
            xe3.frame = CGRect(x:CGFloat(r ), y: xe3.frame.origin.y, width: xe3.frame.size.width, height: xe3.frame.size.height) //chỗ này thay = CGFloat(r) cũng đc
            
            var diem:Int? = Int(lblDiem.text!)
            diem = diem! + 1
            lblDiem.text = String(diem!)
        }
        
        //kiem tra đụng xe
        
        if  xe1.frame.intersects(xeBoMay.frame) || xe2.frame.intersects(xeBoMay.frame) || xe3.frame.intersects(xeBoMay.frame) {
            timer.invalidate()
            
        }
        
        
    }
    
    
    var w:CGFloat!, h:CGFloat!
    
    
    
    @IBOutlet weak var lblDiem: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        //lay size man hinh
        w = self.view.frame.width
        h = self.view.frame.height
        
        	//chen hinh nen duong
        self.view.backgroundColor = UIColor(patternImage: UIImage(named:"matduong.png")!)
        //xac dinh vi tri xe 
        
        xe1.frame = CGRect(x: xe1.frame.origin.x, y: xe1.frame.origin.y -  600, width: xe1.frame.size.width, height: xe1.frame.size.height)
        xe2.frame = CGRect(x: xe2.frame.origin.x, y: xe2.frame.origin.y -  600, width: xe2.frame.size.width, height: xe2.frame.size.height)
        xe3.frame = CGRect(x: xe3.frame.origin.x, y: xe3.frame.origin.y -  600, width: xe3.frame.size.width, height: xe3.frame.size.height)
        
        
        
        
    }

    @IBAction func KeoTha(_ Reconizer:UIPanGestureRecognizer) {
        let tran = Reconizer.translation(in: self.view)
        Reconizer.view!.center = CGPoint(x: Reconizer.view!.center.x + tran.x, y: Reconizer.view!.center.y + tran.y)
        Reconizer.setTranslation(CGPoint.zero, in: self.view)
        
    }
    
    @IBAction func keotha1(_ Reconizer:UIPanGestureRecognizer) {
        let tran = Reconizer.translation(in: self.view)
        Reconizer.view!.center = CGPoint(x: Reconizer.view!.center.x + tran.x, y: Reconizer.view!.center.y + tran.y)
        Reconizer.setTranslation(CGPoint.zero, in: self.view)
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

